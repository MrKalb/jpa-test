package com.example.jpatest.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
@Entity
@Table(name="SHIPPING_GROUP")
public class ShippingGroupEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "ORDER_ID_SEQ")
	@SequenceGenerator(name = "ORDER_ID_SEQ", sequenceName = "ORDER_ID_SEQ",allocationSize=1)
	@Column(name = "ID")
	private Long id; 
	
	
	private String shippingGroupId; 
	
	private String status; 
	
	private Integer quantity; 
	
}
