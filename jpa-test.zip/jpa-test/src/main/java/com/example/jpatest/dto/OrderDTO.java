package com.example.jpatest.dto;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class OrderDTO {

	private String orderId; 
	
	private String status; 
	
	private List<ShippingDTO> shippings; 
	
	
}
