package com.example.jpatest.entities;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
@Entity
@Table(name="ORDER")
public class OrderEntity {

	private Long id; 
	
	private String orderId; 
	
	private String status; 
	
	private Set<ShippingGroupEntity> shippings; 
	
}
