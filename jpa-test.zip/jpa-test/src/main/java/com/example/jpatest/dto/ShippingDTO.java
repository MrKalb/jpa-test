package com.example.jpatest.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ShippingDTO {
	
	private String shippingGroupId; 
	
	private String status; 
	
	private Integer quantity; 
	
}
